#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2023/12/13 下午7:23
# @Author : SiHang Xu
import csv
import os

file_name = 'test_result2.csv'
# 指定结果文件的路径
csv_file_path = "test_result2.csv"

# 打开CSV文件，使用 'a' 模式
with open(csv_file_path, 'a', newline='') as csvfile:
    # 创建CSV写入对象
    csv_writer = csv.writer(csvfile)


    # 遍历目录中的文件
    for i in os.listdir('./normal'):
        image_path = './normal/' + i
        result = 0
        image_name = i

        # 将结果写入CSV文件
        if result is not None:
            csv_writer.writerow([image_name, int(result * 100)])
            print(image_name, result*100)
        else:
            print(f"无法处理 {image_name}")
