#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2023/12/13 下午7:10
# @Author : SiHang Xu
import csv
import os

from PIL import Image

def calculate_non_black_pixel_ratio(image_path):
    try:
        # 打开图片
        image = Image.open(image_path)

        # 获取图片大小
        width, height = image.size

        # 初始化非黑色像素计数
        non_black_count = 0

        # 遍历图片像素
        for y in range(height):
            for x in range(width):
                # 获取像素颜色
                pixel = image.getpixel((x, y))

                # 检查是否为纯黑色
                if pixel != (0, 0, 0):
                    non_black_count += 1

        # 计算非黑色像素占比
        total_pixels = width * height
        non_black_ratio = non_black_count / total_pixels

        return non_black_ratio

    except Exception as e:
        print(f"Error: {e}")
        return None



# 指定结果文件的路径
csv_file_path = "test_result2.csv"

# 打开CSV文件，使用 'w' 模式
with open(csv_file_path, 'w', newline='') as csvfile:
    # 创建CSV写入对象
    csv_writer = csv.writer(csvfile)

    # 写入表头
    csv_writer.writerow(['fnames', 'pothole %'])

    # 遍历目录中的文件
    for i in os.listdir('./result'):
        image_path = './result/' + i
        result = calculate_non_black_pixel_ratio(image_path)
        image_name = i.split('_')[0] + '.jpg'

        # 将结果写入CSV文件
        if result is not None:
            csv_writer.writerow([image_name, int(result * 100)])
            print(image_name, result*100)
        else:
            print(f"无法处理 {image_name}")

print(f"数据已保存到 {csv_file_path}")