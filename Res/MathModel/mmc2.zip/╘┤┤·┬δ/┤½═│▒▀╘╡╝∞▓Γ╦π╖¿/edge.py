import cv2
import os
import numpy as np

def laplacian_edge_detection(image_path, alpha=3, beta=30):
    # Read the image
    original_image = cv2.imread("images/" + image_path, cv2.IMREAD_GRAYSCALE)
    original_images = cv2.imread("images/" + image_path)

    # Apply GaussianBlur to reduce noise and help with edge detection
    blurred_image = cv2.GaussianBlur(original_image, (5, 5), 0)

    # Apply Laplacian edge detection
    laplacian = cv2.Laplacian(blurred_image, cv2.CV_64F)

    # Convert the Laplacian result to uint8 (8-bit) for display
    laplacian = np.uint8(np.absolute(laplacian))

    # Adjust brightness and contrast
    laplacian_adjusted = cv2.convertScaleAbs(laplacian, alpha=alpha, beta=beta)

    # Display the original and adjusted Laplacian edge-detected images
    cv2.imwrite(os.path.join('output', image_path), laplacian_adjusted)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Replace 'path/to/your/image.jpg' with the actual path to your image file
for image in os.listdir("images"):
    laplacian_edge_detection(image)
