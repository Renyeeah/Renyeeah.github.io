#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 图像增广
# @Time : 2023/12/12 下午8:05
# @Author : SiHang Xu
from torchvision import transforms
from PIL import Image
import os
import random

count = 0


def augment_images(input_path, output_path, seed=42):
    global count
    # 设置随机数种子


    random.seed(seed)

    # 创建输出路径
    os.makedirs(output_path, exist_ok=True)

    # 获取两组图片的文件名列表
    files_group1 = os.listdir(input_path + '/JPEGImages')
    files_group2 = os.listdir(input_path + '/SegmentationClass')

    # 对每一对文件进行相同的增广操作
    for file1, file2 in zip(files_group1, files_group2):
        image1 = Image.open(os.path.join(input_path + '/JPEGImages', file1))
        image2 = Image.open(os.path.join(input_path + '/SegmentationClass', file2))

        # 对两组图像应用相同的随机数操作
        random.seed(seed)
        rand_val = random.random()

        augmentations = transforms.Compose([
            transforms.RandomHorizontalFlip(p=1),
            # 添加其他需要的增广操作
        ])
        # 设置相同的随机数种子，确保增广一致
        augmented_image1 = augmentations(image1)
        augmented_image2 = augmentations(image2)

        # 保存增广后的图片
        augmented_image1.save(os.path.join(output_path, 'JPEGImages', str(count) + '.png'))
        augmented_image2.save(os.path.join(output_path, 'SegmentationClass', str(count) + '.png'))
        count += 1


def aug_images(input_path, output_path, seed=42):
    global count
    # 设置随机数种子


    random.seed(seed)

    # 创建输出路径
    os.makedirs(output_path, exist_ok=True)

    # 获取两组图片的文件名列表
    files_group1 = os.listdir(input_path + '/JPEGImages')
    files_group2 = os.listdir(input_path + '/SegmentationClass')

    # 对每一对文件进行相同的增广操作
    for file1, file2 in zip(files_group1, files_group2):
        image1 = Image.open(os.path.join(input_path + '/JPEGImages', file1))
        image2 = Image.open(os.path.join(input_path + '/SegmentationClass', file2))

        # 对两组图像应用相同的随机数操作
        random.seed(seed)
        rand_val = random.random()

        augmentations = transforms.Compose([
            transforms.RandomVerticalFlip(p=1),
            # 添加其他需要的增广操作
        ])
        # 设置相同的随机数种子，确保增广一致
        augmented_image1 = augmentations(image1)
        augmented_image2 = augmentations(image2)

        # 保存增广后的图片
        augmented_image1.save(os.path.join(output_path, 'JPEGImages', str(count) + '.png'))
        augmented_image2.save(os.path.join(output_path, 'SegmentationClass', str(count) + '.png'))
        count += 1


def gauss_images(input_path, output_path, seed=42):
    global count
    # 设置随机数种子


    random.seed(seed)

    # 创建输出路径
    os.makedirs(output_path, exist_ok=True)

    # 获取两组图片的文件名列表
    files_group1 = os.listdir(input_path + '/JPEGImages')
    files_group2 = os.listdir(input_path + '/SegmentationClass')

    # 对每一对文件进行相同的增广操作
    for file1, file2 in zip(files_group1, files_group2):
        image1 = Image.open(os.path.join(input_path + '/JPEGImages', file1))
        image2 = Image.open(os.path.join(input_path + '/SegmentationClass', file2))

        # 对两组图像应用相同的随机数操作
        random.seed(seed)
        rand_val = random.random()

        augmentations = transforms.Compose([
            transforms.GaussianBlur(kernel_size=11, sigma=5)
            # 添加其他需要的增广操作
        ])
        # 设置相同的随机数种子，确保增广一致
        augmented_image1 = augmentations(image1)
        augmented_image2 = image2

        # 保存增广后的图片
        augmented_image1.save(os.path.join(output_path, 'JPEGImages', str(count) + '.png'))
        augmented_image2.save(os.path.join(output_path, 'SegmentationClass', str(count) + '.png'))
        count += 1

    # 用法示例
input_path = './test'
output_path = './output'

augment_images(input_path, output_path)
aug_images(input_path, output_path)
gauss_images(input_path, output_path)
