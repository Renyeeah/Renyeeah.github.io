#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 这段代码负责将labelme标注后的文件转换为正确的格式
# @Time : 2023/12/15 下午12:56
# @Author : SiHang Xu
import os
files=os.listdir('./')
files.remove('json2dataset.py')   # 删除这个py文件本身
for i in range(len(files)):
    os.system('labelme_json_to_dataset '+files[i])
