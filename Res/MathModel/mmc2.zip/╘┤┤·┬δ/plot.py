import pandas as pd
import matplotlib.pyplot as plt

# 从CSV文件中读取数据
csv_file_path = 'outputresnet150.csv'
df = pd.read_csv(csv_file_path)

# 获取迭代次数和损失值列
epochs = df['Epoch']

# 设置图形大小
plt.figure(figsize=(10, 5))

# 绘制损失函数曲线图
plt.plot(epochs, df['FWIoU'], label='FWIoU', color='lightpink', linestyle='-', linewidth=2, marker='o', markersize=5)
plt.xlabel('Epoch', fontsize=14)
plt.ylabel('FWIoU', fontsize=14)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend(fontsize=14)
plt.tight_layout()  # 调整布局，防止标签被截断
plt.show()
