#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2023/12/15 下午2:09
# @Author : SiHang Xu
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset
import cv2

class MyDataset(Dataset):
    def __init__(self, txt_path):
        super(MyDataset, self).__init__()

        with open(txt_path, "r") as file:
            image_label = [line.strip() for line in file]

        self.image_label = image_label

    def __getitem__(self, item):
        root = self.image_label[item]
        image_path = f'./400dataset/JPEGImages/{root}.png'
        label_path = f'./400dataset/SegmentationClass/{root}.png'

        image = cv2.imread(image_path)
        image = cv2.resize(image, (224, 224))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Convert to RGB
        image = image / 255.0  # Normalize input
        image = torch.tensor(image, dtype=torch.float32)
        image = image.permute(2, 0, 1)

        label = Image.open(label_path)
        label = label.resize((224, 224), Image.NEAREST)  # 使用最近邻插值
        label = np.array(label)
        label = torch.tensor(label, dtype=torch.long)
        # label = cv2.imread(label_path, cv2.IMREAD_GRAYSCALE)
        # label = cv2.resize(label, (224, 224))
        # label = torch.tensor(label, dtype=torch.long)  # Assuming segmentation labels are integers

        return image, label

    def __len__(self):
        return len(self.image_label)
