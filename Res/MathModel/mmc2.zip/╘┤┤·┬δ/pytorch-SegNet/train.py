#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2023/12/15 下午2:11
# @Author : SiHang Xu
import csv
import logging
import time

import cv2
import numpy as np
from torch.utils import data as Data
from MyDataset import MyDataset
from SegNet import *


def calculate_iou(confusion_matrix):
    intersection = confusion_matrix.diagonal()
    union = confusion_matrix.sum(axis=1) + confusion_matrix.sum(axis=0) - intersection
    iou = intersection / union
    return iou


def calculate_miou(confusion_matrix):
    return np.mean(calculate_iou(confusion_matrix))


def calculate_fwiou(confusion_matrix):
    frequency = confusion_matrix.sum(axis=1) / confusion_matrix.sum()
    fwiou = np.sum(frequency * calculate_iou(confusion_matrix))
    return fwiou

epoch_data = []
def train_and_validate(SegNet, train_data, val_data, BATCH_SIZE, LR, MOMENTUM, EPOCH, CATE_WEIGHT, WEIGHTS, PRE_TRAINING):
    SegNet = SegNet(3, 2).cuda()
    SegNet.load_weights(PRE_TRAINING)

    train_loader = torch.utils.data.DataLoader(train_data, batch_size=BATCH_SIZE, shuffle=True, drop_last=True, num_workers=12)
    val_loader = torch.utils.data.DataLoader(val_data, batch_size=BATCH_SIZE, shuffle=False, drop_last=True, num_workers=12)

    optimizer = torch.optim.SGD(SegNet.parameters(), lr=LR, momentum=MOMENTUM)

    loss_func = nn.CrossEntropyLoss(weight=torch.from_numpy(np.array(CATE_WEIGHT)).float()).cuda()

    for epoch in range(EPOCH):
        # Training
        SegNet.train()
        for step, (b_x, b_y) in enumerate(train_loader):
            b_x = b_x.cuda()
            b_y = b_y.cuda()
            b_y = b_y.view(BATCH_SIZE, 224, 224)
            output = SegNet(b_x)
            loss = loss_func(output, b_y.long())
            loss = loss.cuda()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        print(f"Epoch: {epoch} || Training Loss: {loss:.4f}")

        # Validation
        SegNet.eval()
        confusion_matrix = np.zeros((2, 2), dtype=int)
        with torch.no_grad():
            val_loss = 0.0

            for step, (val_x, val_y) in enumerate(val_loader):
                val_x = val_x.cuda()
                val_y = val_y.cuda()
                val_y = val_y.view(BATCH_SIZE, 224, 224)
                val_output = SegNet(val_x)
                val_loss += loss_func(val_output, val_y.long()).item()

                val_output = torch.squeeze(val_output)

                predict = val_output.argmax(dim=1)
                target = val_y
                confusion_matrix += np.bincount(
                    (2 * target.flatten() + predict.flatten()).cpu().numpy(),
                    minlength=2 ** 2).reshape(2, 2)

            miou = calculate_miou(confusion_matrix)
            fwiou = calculate_fwiou(confusion_matrix)

            acc = (confusion_matrix.diagonal().sum() / confusion_matrix.sum())
            acc_class = confusion_matrix.diagonal() / confusion_matrix.sum(axis=1)
            print('Epoch: {}, Acc: {:.4f}, Acc_class: {}, mIoU: {:.4f}, FWIoU: {:.4f}'.format(epoch, acc,
                                                                                                     acc_class,
                                                                                                     miou,
                                                                                                     fwiou))
            epoch_data.append((epoch, acc, acc_class, miou, fwiou))

    torch.save(SegNet.state_dict(), WEIGHTS + "SegNet_weights" + str(time.time()) + ".pth")
    with open('output.csv', 'w', newline='') as csvfile:
        # 创建CSV写入对象
        csv_writer = csv.writer(csvfile)

        # 写入表头
        csv_writer.writerow(['Epoch', 'Acc', 'Acc_class', 'mIoU', 'FWIoU'])

        # 写入数据
        csv_writer.writerows(epoch_data)

# 示例调用
BATCH_SIZE = 8
LR = 0.001
MOMENTUM = 0.9
EPOCH = 50
CATE_WEIGHT = [1, 1]  # 根据实际情况调整
WEIGHTS = "weights/"
PRE_TRAINING = "vgg16_bn-6c64b313.pth"
train_data = MyDataset(txt_path='train.txt')
val_data = MyDataset(txt_path='trainval.txt')

train_and_validate(SegNet, train_data, val_data, BATCH_SIZE, LR, MOMENTUM, EPOCH, CATE_WEIGHT, WEIGHTS, PRE_TRAINING)
