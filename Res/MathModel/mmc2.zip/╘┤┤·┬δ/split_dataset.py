#随机生成trian.txt, trainval.txt, val.txt

import os
import random

# 设置路径和文件名
path = "./JPEGImages"  # 替换为你的图片所在的路径
train_file = "train.txt"
trainval_file = "trainval.txt"
val_file = "val.txt"

# 获取路径下的所有图片文件
image_files = [f for f in os.listdir(path) if f.endswith(".jpg") or f.endswith(".png")]

# 打乱文件列表
random.shuffle(image_files)

# 计算划分的索引
total_images = len(image_files)
train_split = 1400
trainval_split = 1500

# 划分文件列表
train_images = [os.path.splitext(f)[0] for f in image_files[:train_split]]
trainval_images = [os.path.splitext(f)[0] for f in image_files[train_split:trainval_split]]
val_images = [os.path.splitext(f)[0] for f in image_files[trainval_split:]]

# 写入文件名到train.txt
with open(train_file, "w") as f:
    f.write("\n".join(train_images))

# 写入文件名到trainval.txt
with open(trainval_file, "w") as f:
    f.write("\n".join(trainval_images))

# 写入文件名到val.txt
with open(val_file, "w") as f:
    f.write("\n".join(val_images))

