clear
co_xy=xlsread('����.xlsx');%���վ���������xy
fenlei=xlsread('�������.xlsx');
N=size(co_xy,1);%���վ���Ŀ
co_z=4;%����z������װ�߶�
co_ding=[co_xy,ones(N,1)*co_z];%���վ���������
time0=0;
Dsum=0;
xx0=1;
for D=[306,337,0,31,61,92,122,153,184,214,245,275]
    yy0=1;
    sum=0;
    tic
    for t=[9, 10.5, 12, 13.5, 15]
        
        for i =1:N
            
            if  ismember(i,fenlei(:,18))
                continue
            end
            
            [~,juan]=find(fenlei==i);
            if juan<=17
                zhedang0=fenlei(:,juan+1);
                zhedang1=zhedang0(~isnan(zhedang0));
                
                dist=0;
                for i0=1:length(zhedang1)
                    dist(i0)=norm(co_xy(i,:)-co_xy(zhedang1(i0),:));
                end
                [sx,sy]=sort(dist);
                choose=sy(1:3);
                
                
                for j0= 1:length(choose)
                    j=zhedang1(choose(j0));
                    s1=fleft_area(D,t,co_ding(i,:),co_ding(j,:));
                    s2=fright_area(D,t,co_ding(i,:),co_ding(j,:));
                    sum=sum+s1+s2;
                end
                
            end
        end
        Dsum(xx0,yy0)=sum
        time0(xx0,yy0)=toc
        yy0=yy0+1;
    end
    
    xx0=xx0+1;
end

% save all_306337031 Dsum time0