import torch.utils.data as data
import os
import cv2

class dataloader(data.Dataset):
    def __init__(self, data_root, transform):
        self.data_root = data_root
        self.transform = transform
        self.items = []
        self.label = []
        for i in os.listdir(data_root):
            image = cv2.imread(os.path.join(self.data_root, i), 1)
            # image = hisEqulColor1(image)
            image = self.transform(image)
            self.items.append(image)
            if(i.startswith('normal')):
                self.label.append(0)
            else:
                self.label.append(1)

    def __getitem__(self, item):
        image = self.items[item]
        label = self.label[item]
        if self.transform:
            image = self.transform(image)

        return image, label

    def __len__(self):
        return len(self.items)
