import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models
from torchvision import models


class VGG16(nn.Module):
    def __init__(self):
        super(VGG16, self).__init__()

        self.vgg = torchvision.models.vgg16(pretrained=False)

        self.vgg.classifier = nn.Sequential(
            nn.Linear(25088, 4096),
            nn.ReLU(True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(True),
            nn.Dropout(),
            nn.Linear(4096, 2)
        )

    def forward(self, x):
        return self.vgg(x)


class VGG19(nn.Module):
    def __init__(self):
        super(VGG19, self).__init__()
        self.vgg = torchvision.models.vgg19(pretrained=False)

        self.vgg.classifier = nn.Sequential(
            nn.Linear(25088, 4096),
            nn.ReLU(True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(True),
            nn.Dropout(),
            nn.Linear(4096, 2)
        )
    def forward(self, x):
        return self.vgg(x)
