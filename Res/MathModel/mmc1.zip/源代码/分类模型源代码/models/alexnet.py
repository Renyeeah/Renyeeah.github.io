import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models
from torchvision import models

class AlexNet(nn.Module):
    def __init__(self):
        super(AlexNet, self).__init__()
        self.alexnet = torchvision.models.alexnet(pretrained = False)
        self.alexnet.classifier = nn.Sequential(
            nn.Linear(256 * 6 * 6, 4096),  # 自定义全连接层
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, 2)
        )

    def forward(self, x):
        return self.alexnet(x)