import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models
from torchvision import models

class ResNet18(nn.Module):
    def __init__(self, num_classes=2):
        super(ResNet18, self).__init__()
        self.resnet = torchvision.models.resnet18(pretrained=True)
        num_ftrs = self.resnet.fc.in_features
        self.dropout = nn.Dropout(p=0.5)

        self.resnet.fc = nn.Sequential(
            self.dropout,
            nn.Linear(num_ftrs, num_classes)
        )

    def forward(self, x):
        return self.resnet(x)


class ResNet34(nn.Module):
    def __init__(self, num_classes=2):
        super(ResNet34, self).__init__()
        self.resnet = torchvision.models.resnet34(pretrained=False)
        num_ftrs = self.resnet.fc.in_features
        self.dropout = nn.Dropout(p=0.5)


        self.resnet.fc = nn.Sequential(
            self.dropout,
            nn.Linear(num_ftrs, num_classes)
        )

    def forward(self, x):
        return self.resnet(x)

class ResNet50(nn.Module):
    def __init__(self, num_classes=2):
        super(ResNet50, self).__init__()
        self.resnet = torchvision.models.resnet50(pretrained=False)
        num_ftrs = self.resnet.fc.in_features
        self.dropout = nn.Dropout(p=0.5)


        self.resnet.fc = nn.Sequential(
            self.dropout,
            nn.Linear(num_ftrs, num_classes)
        )

    def forward(self, x):
        return self.resnet(x)




