import os
import torch
from torchvision.transforms import transforms
import cv2
from models.SEnet import *
import csv

# model = SE_ResNet18().cuda().eval()
#
# model.load_state_dict(torch.load('SENet.pt'))

model = torch.load('best.pt').cuda().eval()

data_root = './testdata_V2'

transform_test = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])






# 初始化一个CSV文件
csv_file = 'test_result.csv'

# 打开CSV文件以写入结果
with open(csv_file, mode='w', newline='') as file:
    fieldnames = ['fname', 'label']
    writer = csv.DictWriter(file, fieldnames=fieldnames)
    writer.writeheader()

    # 遍历数据根目录中的文件/子目录
    for i in os.listdir(data_root):
        image_root = os.path.join(data_root, i)
        image = cv2.imread(image_root)
        image = transform_test(image)
        image = image.unsqueeze(0)
        image = image.cuda()
        output = model(image)
        _, predicted = torch.max(output, 1)

        # 设置label值
        label = 1 if predicted.item() == 0 else 0

        # 写入CSV文件
        writer.writerow({'fname': i, 'label': label})

print("CSV文件已创建并写入结果。")
