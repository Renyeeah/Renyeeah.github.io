import os
import random
import numpy as np
from torch.utils.data import DataLoader
from torchvision.transforms import transforms
from sklearn.metrics import recall_score, roc_curve, auc, f1_score
from models.resnet import *
from models.SEnet import *
from Dataloder import dataloader
import warnings
import cv2
from PIL import Image
# 忽略 UserWarning
warnings.filterwarnings("ignore", category=UserWarning)

# 设置随机种子
seed = 79
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

# 定义ResNet-18模型

def apply_bilateral_filter(image):
    # 转换PIL图像为NumPy数组
    image = np.array(image)

    # 使用双边滤波
    image = cv2.bilateralFilter(image, d=9, sigmaColor=75, sigmaSpace=75)

    # 将处理后的图像转换回PIL图像
    image = Image.fromarray(image)

    return image

class EqualizeColorHistogram(object):
    def __call__(self, img):
        img_np = np.array(img)
        # 拆分通道
        b, g, r = cv2.split(img_np)
        # 对每个通道进行直方图均衡化
        equalized_b = cv2.equalizeHist(b)
        equalized_g = cv2.equalizeHist(g)
        equalized_r = cv2.equalizeHist(r)
        # 合并三个通道
        equalized_img = cv2.merge((equalized_b, equalized_g, equalized_r))
        return Image.fromarray(equalized_img)

# 定义数据预处理和转换
transform = transforms.Compose([
    transforms.ToPILImage(),  # 将NumPy数组转换为PIL图像
    transforms.Resize((224, 224)),  # 调整图像大小
    # transforms.RandomHorizontalFlip(),
    # transforms.RandomVerticalFlip(),
    # transforms.ColorJitter(),
    EqualizeColorHistogram(),
    transforms.ToTensor(),  # 将图像转换为张量
])


acc = []
rc_normal = []
rc_potholes = []
auc_list = []
f1 = []

epoch = 30
lr = 0.0001
eta_min = 1e-8


def train(data_loader, epoch, model, optimizer, scheduler, lr, loss_fn):
    # 损失函数，你需要根据你的任务选择适当的损失函数
    criterion = loss_fn

    for e in range(epoch):
        model.train()  # 设置模型为训练模式
        running_loss = 0.0
        correct = 0
        total = 0

        for inputs, labels in data_loader:
            inputs = inputs.cuda()
            labels = labels.cuda()
            optimizer.zero_grad()  # 梯度清零

            # 正向传播
            outputs = model(inputs)
            # outputs = outputs.logits
            loss = criterion(outputs, labels)

            # 反向传播和优化
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            # 计算正确率
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        accuracy = 100 * correct / total

        # 更新学习率（如果使用学习率调度器）
        if scheduler is not None:
            scheduler.step()
            current_lr = optimizer.param_groups[0]['lr']




# 计算recall
true_normal = []
true_potholes = []
def test(data_loader, model, loss_fn):
    model.eval()  # 设置模型为评估模式
    running_loss = 0.0
    correct = 0
    total = 0
    true_labels = []
    predicted_labels = []

    with torch.no_grad():
        for inputs, labels in data_loader:
            inputs = inputs.cuda()
            labels = labels.cuda()

            outputs = model(inputs)
            loss = loss_fn(outputs, labels)
            running_loss += loss.item()

            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            # AUC
            true_labels.extend(labels.cpu().numpy())
            predicted_labels.extend(predicted.cpu().numpy())

    accuracy = 100 * correct / total
    acc.append(accuracy)

    # 计算召回率
    recall_normal = recall_score(true_labels, predicted_labels, pos_label=0)
    recall_potholes = recall_score(true_labels, predicted_labels, pos_label=1)
    f1_sc = f1_score(true_labels, predicted_labels)

    # 计算AUC
    fpr, tpr, thresholds = roc_curve(true_labels, predicted_labels)
    auc_score = auc(fpr, tpr)
    rc_normal.append(recall_normal)
    rc_potholes.append(recall_potholes)
    auc_list.append(auc_score)
    f1.append(f1_sc)
    print(f"Acc = {accuracy:.2f}, recall_normal = {recall_normal:.4f}, recall_potholes = {recall_potholes:.4f}, auc = {auc_score:.4f}, f1-score = {f1_sc:.4f}")

import time

start_time = time.time()

for i in range(5):
    model = ResNet18().cuda()

    loss = nn.CrossEntropyLoss()
    optim = torch.optim.Adam(model.parameters(), lr)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer=optim, T_max=int(epoch), eta_min=eta_min)

    data_root_train = './data_new_new/data' + str(i+1)
    train_dataloader = dataloader(data_root=os.path.join(data_root_train, 'train'), transform=transform)
    train_loader = DataLoader(dataset=train_dataloader, num_workers=12, batch_size=8, persistent_workers=False, drop_last=False)

    data_root_test = './data_new_new/data' + str(i+1)
    test_dataloader = dataloader(data_root=os.path.join(data_root_train, 'test'), transform=transform)
    test_loader = DataLoader(dataset=test_dataloader, num_workers=12, batch_size=4, persistent_workers=False)
    # 调用train函数
    train(data_loader=train_loader, epoch=epoch, model=model, optimizer=optim, scheduler=scheduler, loss_fn=loss, lr=lr)
    test(data_loader=test_loader, model=model, loss_fn=loss)
    torch.save(model.state_dict(), "SENet.pt")

end_time = time.time()
cost_time = end_time - start_time
print('Average Acc', sum(acc) / len(acc))
print('Average Recall Normal', sum(rc_normal) / len(rc_normal))
print('Average Recall Potholes', sum(rc_potholes) / len(rc_potholes))
print('Average AUC', sum(auc_list) / len(auc_list))
print('Average F1', sum(f1)/len(f1))
print('Cost Time', cost_time)