# -*- coding: utf-8 -*-
import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt


acc = []
recall1 = []
recall2 = []
auc_score = []
f1score = []

def draw_3D(hist):
    hist = np.reshape(hist, (256, 256))
    # Create a mesh grid for X and Y values
    x = np.linspace(0, 255, 256)
    y = np.linspace(0, 255, 256)
    x, y = np.meshgrid(x, y)

    # Create a 3D plot
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # Plot the 3D histogram
    ax.plot_surface(x, y, hist, cmap='viridis')

    # Set labels
    ax.set_xlabel('Channel 0')
    ax.set_ylabel('Channel 1')
    ax.set_zlabel('Frequency')

    # Show the plot
    plt.show()

for j in range(1,6):
    X_train = []
    X_test = []
    y_train = []
    y_test = []
    data_root = './data_new_new/data'+str(j)
    for i in os.listdir(data_root + '/train'):
        X_train.append(os.path.join(data_root + '/train', i))
        if i.startswith('normal'):
            y_train.append(0)
        else:
            y_train.append(1)

    for i in os.listdir(data_root + '/test'):
        X_test.append(os.path.join(data_root + '/test', i))
        if i.startswith('normal'):
            y_test.append(0)
        else:
            y_test.append(1)
    #
    # print(len(X_train), len(X_test), len(y_train), len(y_test))


    XX_train = []
    for i in X_train:
        image = cv2.imdecode(np.fromfile(i, dtype=np.uint8), cv2.IMREAD_COLOR)
        img = cv2.resize(image, (256, 256),
                         interpolation=cv2.INTER_CUBIC)
        hist = cv2.calcHist([img], [0, 1], None,
                            [256, 256], [0.0, 255.0, 0.0, 255.0])

        XX_train.append(((hist / 255).flatten()))

    # 测试集
    XX_test = []
    for i in X_test:
        image = cv2.imdecode(np.fromfile(i, dtype=np.uint8), cv2.IMREAD_COLOR)

        img = cv2.resize(image, (256, 256),
                         interpolation=cv2.INTER_CUBIC)
        hist = cv2.calcHist([img], [0, 1], None,
                            [256, 256], [0.0, 255.0, 0.0, 255.0])


        XX_test.append(((hist / 255).flatten()))



    # ----------------------------------------------------------------------------------
    # 第三步 基于支持向量机的图像分类处理
    # ----------------------------------------------------------------------------------
    # 0.5
    # 常见核函数‘linear’, ‘poly’, ‘rbf’, ‘sigmoid’, ‘precomputed’
    clf = SVC().fit(XX_train, y_train)
    clf = SVC(kernel="linear").fit(XX_train, y_train)
    predictions_labels = clf.predict(XX_test)

    # ----------------------------------------------------------------------------------
    # 第三步 基于决策树的图像分类处理
    # ----------------------------------------------------------------------------------
    # 0.36
    # from sklearn.tree import DecisionTreeClassifier
    # clf = DecisionTreeClassifier().fit(XX_train, y_train)
    # predictions_labels = clf.predict(XX_test)

    # ----------------------------------------------------------------------------------
    # 第三步 基于KNN的图像分类处理
    # ----------------------------------------------------------------------------------
    # 0.11
    # from sklearn.neighbors import KNeighborsClassifier
    # clf = KNeighborsClassifier(n_neighbors=11).fit(XX_train, y_train)
    # predictions_labels = clf.predict(XX_test)

    # ----------------------------------------------------------------------------------
    # 第三步 基于朴素贝叶斯的图像分类处理0.
    # ----------------------------------------------------------------------------------
    # 0.01
    # from sklearn.naive_bayes import BernoulliNB
    # clf = BernoulliNB().fit(XX_train, y_train)
    # predictions_labels = clf.predict(XX_test)

    # print(u'预测结果:')
    # print(predictions_labels)
    # print(u'算法评价:')
    # print(classification_report(y_test, predictions_labels))
    #


    # labels = ['0', '1']



    y_true = y_test  # 正确标签
    y_pred = predictions_labels  # 预测标签

    from sklearn.metrics import roc_auc_score, recall_score, accuracy_score, f1_score

    auc = roc_auc_score(y_true, y_pred)
    recall_class_0 = recall_score(y_true, y_pred, pos_label=0)
    recall_class_1 = recall_score(y_true, y_pred, pos_label=1)
    acc_score = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred)

    acc.append(acc_score)
    auc_score.append(auc)
    recall1.append(recall_class_0)
    recall2.append(recall_class_1)
    f1score.append(f1)

print('Acc', sum(acc)/len(acc))
print('Recall1', sum(recall1)/len(recall1))
print('Recall2', sum(recall2)/len(recall2))
print('AUC', sum(auc_score)/len(auc_score))
print('F1', sum(f1score)/len(f1score))

