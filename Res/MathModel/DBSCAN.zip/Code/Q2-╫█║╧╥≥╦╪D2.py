
from utils import *
from mpl_toolkits.mplot3d import Axes3D


# 按顺序把stops和begins合并
def Guibing(stops, begins):
    stopsAndbegins = []
    for i in range(len(stops)):
        stopsAndbegins.append((stops[i], begins[i]))
    n = len(stopsAndbegins)
    for i in range(n):
        for j in range(0, n - i - 1):
            if stopsAndbegins[j][0] > stopsAndbegins[j + 1][0]:
                stopsAndbegins[j], stopsAndbegins[j + 1] = stopsAndbegins[j + 1], stopsAndbegins[j]
    return stopsAndbegins

# 聚类
def Clustering(A1, distance=0.025):
    A1.sort()
    counts = []
    for i in A1:
        count = 0
        for j in A1:
            if math.fabs(i-j) < distance:
                count += 1

        counts.append(count)
    return counts

def get_a0(id, df):
    A = get_a(id, df)
    A1 = [x[1] for x in A if x[1] < -0.2 and x[0] < getStopTime(id, df)]
    counts = Clustering(A1)
    a0_index = counts.index(max(counts))
    a0 = A1[a0_index]

    t = A[A1.index(a0)][0]
    return a0, t

results1 = []
results2 = []
for item in range(20):
    file = 'B3'
    df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//data//Q2-xy//' + file + '.csv')
    car_ids = set(list(df['vehicle_id']))
    car_ids = list(car_ids)
    num = int(len(car_ids) * 0.575)
    car_ids = random.sample(car_ids, num)
    # if file == 'B1':
    #     lowCar = [16, 20, 45, 93, 139, 170, 330, 554, 657, 759, 847, 1015, 1051, 1068, 1118]
    #     midCar = [238, 245, 246, 717, 721, 731]
    #     highCar = []
    # elif file == 'B2':
    #     lowCar = [54, 122, 168, 204, 344, 376, 385, 434, 436, 468, 549, 774, 811, 812, 851, 887, 928, 972, 1014, 1050,
    #               1063, 1147]
    #     midCar = [72, 85, 93, 501, 499, 505]
    #     highCar = [283, 291, 297, 307]
    #     if 472 in car_ids:
    #         car_ids.remove(472)
    # elif file == 'B3':
    #     lowCar = [230, 235, 718, 839, 881]
    #     midCar = []
    #     highCar = []
    # elif file == 'B4':
    #     lowCar = [138, 299, 337, 374, 404, 459, 496, 520, 677, 689, 744, 779, 819, 851, 882, 951, 1040, 1098, 1130,
    #               1135]
    #     midCar = []
    #     highCar = []
    # elif file == 'B5':
    #     lowCar = [55, 108, 140, 195, 273, 311, 390, 455, 461, 589, 664, 697, 707, 727, 751, 797, 824, 907, 916, 942,
    #               947, 981, 994, 1073, 1153, 1154]
    #     midCar = []
    #     highCar = []

    # 获得汽车的停止时间与启动时间
    stops = []
    stopsv = []
    begins = []
    for id in car_ids:
        if isStop(id, df) == 0:
            V = get_v(id, df)
            A = get_a(id, df)
            A1 = [x[1] for x in A]
            a0, t_a0 = get_a0(id, df)
            sequence = list(range(t_a0, getStopTime(id, df) + 1))

            # 有效时间
            df_car = df[df['vehicle_id'] == id]
            # if id in lowCar:
            #     filter_df = Q2_clearData(df_car, 75)
            # elif id in midCar:
            #     filter_df = Q2_clearData(df_car, 100)
            # elif id in highCar:
            #     filter_df = Q2_clearData(df_car, 125)
            # else:
            #     continue
            filter_df = Q2_clearData(df_car, 100)
            nearTimes = list(filter_df['time'])
            usefulTime = list(set(sequence) & set(nearTimes))

            a1 = []
            for i in A:
                if i[1] < a0 and i[0] in usefulTime:
                    a1.append(i[1])

            if len(a1) == 0:
                stopa = '0.1'
            else:
                stopa = min(a1)

            if stopa == '0.1':
                stops.append(0)
            else:
                stops.append(A[A1.index(stopa)][0])

            # 计算begin
            last_zero_index = -1
            V1 = [x[1] for x in V]
            for index, value in enumerate(V1):
                if value == 0:
                    last_zero_index = index
            begint = V[last_zero_index][0]
            begins.append(begint)

    stopsAndbegins = Guibing(stops, begins)
    delete = []
    for i, j in enumerate(stopsAndbegins):
        if j[0] == 0:
            delete.append(i)
    stopsAndbegins = [element for index, element in enumerate(stopsAndbegins) if index not in delete]
    nStopsAndbegins = normalization(stopsAndbegins)

    C = dbscan(nStopsAndbegins, 0.025, 1)

    Classes = set(C)
    Classes = list(Classes)
    if -1 in Classes:
        Classes.remove(-1)
    begin_classes = []
    stop_classes = []
    for i in Classes:
        this_class_begin = []
        this_class_stop = []
        for k, j in enumerate(C):
            if j == i:
                this_class_begin.append(stopsAndbegins[k][1])
                this_class_stop.append(stopsAndbegins[k][0])

        # 当前车流的全灯周期
        this_begin = sum(this_class_begin) / len(this_class_begin)
        begin_classes.append(this_begin)

        # 当前车流的红灯周期
        stop_classes.append(this_class_begin[0] - this_class_stop[0])

    # 整个红绿灯周期
    begin_classes.sort()
    T = 9999
    for i in range(len(begin_classes)):
        if i == 0:
            continue
        if begin_classes[i] - begin_classes[i - 1] < T:
            T = begin_classes[i] - begin_classes[i - 1]

    T_red = max(stop_classes)
    results1.append(T)
    results2.append(T_red)

print(sum(results1) / len(results1))
print(sum(results2) / len(results2))










