from utils import *

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//1//A1.csv')
car_ids = set(list(df['vehicle_id']))

rg = []
for id in car_ids:
    df_filtered = df[df['vehicle_id'] == id]
    X = list(df_filtered['x'])
    Y = list(df_filtered['y'])
    corrd = [(x, y) for (x, y) in zip(X, Y)]
    if isStop(id, df) == 0:
        count = Counter(corrd)
        most_common_element, most_common_count = count.most_common(1)[0]
        rg.append(most_common_element)

count = Counter(rg)
# 获取按降序排列的所有键值及次数
sorted_counts = count.most_common()

# 打印结果
results = []
for element, cnt in sorted_counts:
    print(f'元素: {element}, 出现次数: {cnt}')
    results.append(element[0])
print(results)


