
from utils import *

df = pd.read_csv('C://Users\RenyeZhang\Desktop\math\data\Q2-xy\A5.csv')
car_ids = set(list(df['vehicle_id']))

# 按顺序把stops和begins合并
def Guibing(stops, begins):
    stopsAndbegins = []
    for i in range(len(stops)):
        stopsAndbegins.append((stops[i], begins[i]))
    n = len(stopsAndbegins)
    for i in range(n):
        for j in range(0, n - i - 1):
            if stopsAndbegins[j][0] > stopsAndbegins[j + 1][0]:
                stopsAndbegins[j], stopsAndbegins[j + 1] = stopsAndbegins[j + 1], stopsAndbegins[j]
    return stopsAndbegins

# 聚类
def Clustering(A1, distance=0.025):
    A1.sort()
    counts = []
    for i in A1:
        count = 0
        for j in A1:
            if math.fabs(i-j) < distance:
                count += 1

        counts.append(count)
    return counts

def get_a0(id, df):
    A = get_a(id, df)
    A1 = [x[1] for x in A if x[1] < -0.2 and x[0] < getStopTime(id, df)]
    counts = Clustering(A1)
    a0_index = counts.index(max(counts))
    a0 = A1[a0_index]

    t = A[A1.index(a0)][0]
    return a0, t

# 获得汽车的停止时间与启动时间
stops = []
stopsv = []
begins = []
for id in car_ids:
    if isStop(id, df) == 0:
        V = get_v(id, df)
        A = get_a(id, df)
        A1 = [x[1] for x in A]
        a0, t_a0 = get_a0(id, df)
        sequence = list(range(t_a0, getStopTime(id, df)+1))

        # 有效时间
        df_car = df[df['vehicle_id'] == id]
        filter_df = clearData(df_car)
        nearTimes = list(filter_df['time'])
        usefulTime = list(set(sequence) & set(nearTimes))

        a1 = []
        for i in A:
            if i[1] < a0 and i[0] in usefulTime:
                a1.append(i[1])

        if len(a1) == 0:
            stopa = '0.1'
        else:
            stopa = min(a1)

        if stopa == '0.1':
            stops.append(0)
        else:
            stops.append(A[A1.index(stopa)][0])

        # 计算begin
        last_zero_index = -1
        V1 = [x[1] for x in V]
        for index, value in enumerate(V1):
            if value == 0:
                last_zero_index = index
        begint = V[last_zero_index][0]
        begins.append(begint)

stopsAndbegins = Guibing(stops, begins)
delete = []
for i, j in enumerate(stopsAndbegins):
    if j[0] == 0:
        delete.append(i)
stopsAndbegins = [element for index, element in enumerate(stopsAndbegins) if index not in delete]
nStopsAndbegins = normalization(stopsAndbegins)

C = dbscan(nStopsAndbegins, 0.025, 2)
print(C)

# 聚类图
# x = []
# y = []
# for data in nStopsAndbegins:
#     x.append(data[0])
#     y.append(data[1])
# plt.figure(figsize=(5, 5), dpi=80)
# plt.scatter(x, y, c=C, marker='o')
# plt.xlabel('stop')
# plt.ylabel('begin')
# plt.show()

Classes = set(C)
Classes = list(Classes)
if -1 in Classes:
    Classes.remove(-1)
begin_classes = []
stop_classes = []
for i in Classes:
    this_class_begin = []
    this_class_stop = []
    for k, j in enumerate(C):
        if j == i:
            this_class_begin.append(stopsAndbegins[k][1])
            this_class_stop.append(stopsAndbegins[k][0])

    # 当前车流的全灯周期
    this_begin = sum(this_class_begin) / len(this_class_begin)
    begin_classes.append(this_begin)

    # 当前车流的红灯周期
    stop_classes.append(this_class_begin[0] - this_class_stop[0])

# 整个红绿灯周期
begin_classes.sort()
T = 9999
for i in range(len(begin_classes)):
    if i == 0:
        continue
    if begin_classes[i] - begin_classes[i-1] < T:
        T = begin_classes[i] - begin_classes[i-1]

T_red = max(stop_classes)

print(T, T_red)
# plt.figure(figsize=(8, 6))
# plt.hist(stop_classes, bins=13, edgecolor='black')  # bins参数指定分成的区间数
# plt.xlabel('Value')
# plt.ylabel('Frequency')
# plt.title('Histogram of Data')
# plt.grid(True)
# plt.tight_layout()
# plt.show()




