
from utils import *



# 按顺序把stops和begins合并
def Guibing(stops, begins):
    stopsAndbegins = []
    for i in range(len(stops)):
        stopsAndbegins.append((stops[i], begins[i]))
    n = len(stopsAndbegins)
    for i in range(n):
        for j in range(0, n - i - 1):
            if stopsAndbegins[j][0] > stopsAndbegins[j + 1][0]:
                stopsAndbegins[j], stopsAndbegins[j + 1] = stopsAndbegins[j + 1], stopsAndbegins[j]
    return stopsAndbegins

# 聚类
def Clustering(A1, distance=0.025):
    A1.sort()
    counts = []
    for i in A1:
        count = 0
        for j in A1:
            if math.fabs(i-j) < distance:
                count += 1

        counts.append(count)
    return counts

def get_a0(id, df):
    A = get_a(id, df)
    A1 = [x[1] for x in A if x[1] < -0.2 and x[0] < getStopTime(id, df)]
    counts = Clustering(A1)
    a0_index = counts.index(max(counts))
    a0 = A1[a0_index]

    t = A[A1.index(a0)][0]
    return a0, t

results1 = []
results2 = []
for item in range(1):
    file = 'D'
    df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//data//Q4-xy//' + file + '.csv')
    dfcar = pd.read_csv('C://Users\RenyeZhang\Desktop\math\data\Q4-车辆分类.csv')
    car_ids = set(list(dfcar['12']))
    car_ids = list(car_ids)
    num = int(len(car_ids) * 1)
    car_ids = random.sample(car_ids, num)
    # if file == 'A1':
    #     lowCar = [46, 158, 162, 197, 284, 418, 446, 464, 486, 506, 620, 640, 668, 682, 898, 905, 956, 993, 1027,
    #               1037, 1067, 1149]
    #     midCar = [99, 101, 102, 125, 123, 134, 225, 226, 236, 347, 359, 367, 766, 776, 775, 829, 840, 839, 869, 874,
    #               880]
    #     highCar = [539, 546, 550, 552]
    # elif file == 'A2':
    #     lowCar = [11, 100, 104, 129, 191, 220, 223, 463, 470, 522, 538, 564, 586, 623, 713, 749, 751, 781, 809, 865,
    #               961, 1015, 1057, 1073, 1111, 1121, 1144]
    #     midCar = []
    #     highCar = []
    #     if 472 in car_ids:
    #         car_ids.remove(472)
    # elif file == 'A3':
    #     lowCar = [53, 64, 154, 156, 190, 325, 328, 388, 435, 447, 482, 565, 578, 603, 662, 701, 702, 762, 765, 805,
    #               903,
    #               919, 982, 1140, 1150]
    #     midCar = [537, 538, 548, 631, 633, 643, 853, 860, 861, 1078, 1093, 1096]
    #     highCar = [287, 289, 293, 295]
    # elif file == 'A4':
    #     lowCar = [20, 119, 211, 301, 340, 369, 423, 482, 484, 521, 532, 556, 561, 604, 620, 638, 692, 797, 860, 862,
    #               950, 1072, 1097, 1103, 1137, 1162, 1165]
    #     midCar = [579, 582, 591, 970, 971, 983, 1038, 1041, 1046]
    #     highCar = [232, 240, 249, 254, 448, 450, 453, 468]
    # elif file == 'A5':
    #     lowCar = [84, 87, 113, 123, 175, 266, 428, 429, 449, 452, 478, 603, 601, 708, 758, 785, 796, 848, 908, 942,
    #               955,
    #               974, 972, 998, 1061, 1066, 1096, 1105, 1157, 1167]
    #     midCar = [1118, 1124, 1135]
    #     highCar = []

    # 获得汽车的停止时间与启动时间
    stops = []
    stopsv = []
    begins = []
    for id in car_ids:
        if isStop(id, df) == 0:
            V = get_v(id, df)
            A = get_a(id, df)
            A1 = [x[1] for x in A]
            a0, t_a0 = get_a0(id, df)
            sequence = list(range(t_a0, getStopTime(id, df) + 1))

            # 有效时间
            df_car = df[df['vehicle_id'] == id]
            # if id in lowCar:
            #     filter_df = Q2_clearData(df_car, 75)
            # elif id in midCar:
            #     filter_df = Q2_clearData(df_car, 100)
            # elif id in highCar:
            #     filter_df = Q2_clearData(df_car, 125)
            # else:
            #     continue
            filter_df = Q2_clearData(df_car, 100)
            nearTimes = list(filter_df['time'])
            usefulTime = list(set(sequence) & set(nearTimes))

            a1 = []
            for i in A:
                if i[1] < a0 and i[0] in usefulTime:
                    a1.append(i[1])

            if len(a1) == 0:
                stopa = '0.1'
            else:
                stopa = min(a1)

            if stopa == '0.1':
                stops.append(0)
            else:
                stops.append(A[A1.index(stopa)][0])

            # 计算begin
            last_zero_index = -1
            V1 = [x[1] for x in V]
            for index, value in enumerate(V1):
                if value == 0:
                    last_zero_index = index
            begint = V[last_zero_index][0]
            begins.append(begint)

    stopsAndbegins = Guibing(stops, begins)
    delete = []
    for i, j in enumerate(stopsAndbegins):
        if j[0] == 0:
            delete.append(i)
    stopsAndbegins = [element for index, element in enumerate(stopsAndbegins) if index not in delete]
    nStopsAndbegins = normalization(stopsAndbegins)

    C = dbscan(nStopsAndbegins, 0.025, 2)

    x = []
    y = []
    for data in nStopsAndbegins:
        x.append(data[0])
        y.append(data[1])
    plt.figure(figsize=(5, 5), dpi=80)
    plt.scatter(x, y, c=C, marker='o')
    plt.xlabel('stop')
    plt.ylabel('begin')
    plt.show()

    Classes = set(C)
    Classes = list(Classes)
    if -1 in Classes:
        Classes.remove(-1)
    begin_classes = []
    stop_classes = []
    for i in Classes:
        this_class_begin = []
        this_class_stop = []
        for k, j in enumerate(C):
            if j == i:
                this_class_begin.append(stopsAndbegins[k][1])
                this_class_stop.append(stopsAndbegins[k][0])

        # 当前车流的全灯周期
        this_begin = sum(this_class_begin) / len(this_class_begin)
        begin_classes.append(this_begin)

        # 当前车流的红灯周期
        stop_classes.append(this_class_begin[0] - this_class_stop[0])

    # 全灯周期
    begin_classes.sort()
    T = 9999
    for i in range(len(begin_classes)):
        if i == 0:
            continue
        if begin_classes[i] - begin_classes[i - 1] < T:
            T = begin_classes[i] - begin_classes[i - 1]


    T_red = max(stop_classes)
    print(T, T_red)

    results1.append(T)
    results2.append(T_red)


    # trueBegins = [x[1] for x in stopsAndbegins]
    # begins_Q3 = []
    # for i in range(max(C)+1):
    #     indices = [index for index, value in enumerate(C) if value == i]
    #     elements = [trueBegins[i] for i in indices]
    #     begins_Q3.append(sum(elements) / len(elements))
    #
    # begins_Q3.sort()
    # begins_Q3.reverse()
    # T_tatal = [begins_Q3[i] - begins_Q3[i+1] for i in range(len(begins_Q3)-1)]
    # T_tatal.reverse()
    # for i, T in enumerate(T_tatal):
    #     if T > 200:
    #         for n in range(2, 20):
    #             if T / n <= 150:
    #                 T_tatal[i] = T / n
    #                 break
    #
    # print(T_tatal)
    # begins_Q3.reverse()
    # stop_classes.pop(0)
    # time_red_green = []
    # print(stop_classes)
    # for i in range(len(T_tatal)):
    #     time = begins_Q3[i]
    #     red = stop_classes[i]
    #     green = T_tatal[i] - red
    #     time_red_green.append((time, red/green))
    #
    # X = [x[0] for x in time_red_green]
    # Y = [x[1] for x in time_red_green]
    # plt.figure(figsize=(5, 5), dpi=80)
    # plt.plot(X, Y,  marker='o')
    # plt.show()






