
from utils import *
from mpl_toolkits.mplot3d import Axes3D
from collections import Counter

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//2//B5.csv')
car_ids = set(list(df['vehicle_id']))

# 按顺序把stops和begins合并
def Guibing(stops, begins):
    stopsAndbegins = []
    for i in range(len(stops)):
        stopsAndbegins.append((stops[i], begins[i]))
    n = len(stopsAndbegins)
    for i in range(n):
        for j in range(0, n - i - 1):
            if stopsAndbegins[j][0] > stopsAndbegins[j + 1][0]:
                stopsAndbegins[j], stopsAndbegins[j + 1] = stopsAndbegins[j + 1], stopsAndbegins[j]
    return stopsAndbegins

# 聚类
def Clustering(A1, distance=0.025):
    A1.sort()
    counts = []
    for i in A1:
        count = 0
        for j in A1:
            if math.fabs(i-j) < distance:
                count += 1

        counts.append(count)
    return counts

def get_a0(id, df):
    A = get_a(id, df)
    A1 = [x[1] for x in A if x[1] < -0.2 and x[0] < getStopTime(id, df)]
    counts = Clustering(A1)
    a0_index = counts.index(max(counts))
    a0 = A1[a0_index]

    t = A[A1.index(a0)][0]
    return a0, t

# 获得汽车的停止时间与启动时间
stops = []
stopsv = []
begins = []
id_stops = []
for id in car_ids:
    if isStop(id, df) == 0:
        V = get_v(id, df)
        A = get_a(id, df)
        A1 = [x[1] for x in A]
        a0, t_a0 = get_a0(id, df)
        sequence = list(range(t_a0, getStopTime(id, df)+1))

        # 有效时间
        df_car = df[df['vehicle_id'] == id]
        filter_df = clearData(df_car)
        nearTimes = list(filter_df['time'])
        usefulTime = list(set(sequence) & set(nearTimes))

        a1 = []
        for i in A:
            if i[1] < a0 and i[0] in usefulTime:
                a1.append(i[1])

        if len(a1) == 0:
            stopa = '0.1'
        else:
            stopa = min(a1)

        if stopa == '0.1':
            stops.append(0)
        else:
            stops.append(A[A1.index(stopa)][0])
            id_stops.append((id, A[A1.index(stopa)][0]))

        # 计算begin
        last_zero_index = -1
        V1 = [x[1] for x in V]
        for index, value in enumerate(V1):
            if value == 0:
                last_zero_index = index
        begint = V[last_zero_index][0]
        begins.append(begint)

stopsAndbegins = Guibing(stops, begins)
delete = []
for i, j in enumerate(stopsAndbegins):
    if j[0] == 0:
        delete.append(i)
stopsAndbegins = [element for index, element in enumerate(stopsAndbegins) if index not in delete]
nStopsAndbegins = normalization(stopsAndbegins)

C = dbscan(nStopsAndbegins, 0.025, 1)
print(C)
lowCar = []
lowClass = []
midCar = []
midClass = []
highCar = []
highClass = []
classNumber = max(C)
for i in range(classNumber+1):
    num = C.count(i)

    if num <= 2:
        lowClass.append(i)
    elif num == 3:
        midClass.append(i)
    else:
        highClass.append(i)

for j, i in enumerate(C):

    id = 0

    stop = stopsAndbegins[j][0]
    for k in id_stops:
        if stop == k[1]:
            id = k[0]

    if i in lowClass:
        lowCar.append(id)
    elif i in midClass:
        midCar.append(id)
    elif i in highClass:
        highCar.append(id)

print(lowCar)
print(midCar)
print(highCar)










