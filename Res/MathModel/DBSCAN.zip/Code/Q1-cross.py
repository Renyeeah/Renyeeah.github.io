import matplotlib.pyplot as plt
import pandas as pd

# 假设已经导入了 utils 模块和其他必要的库

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//1//A5.csv')
df = df[df['vehicle_id'] == 38]

x = df['x']
y = df['y']

plt.figure(figsize=(5, 5))  # 调整图像大小
plt.scatter(x, y, marker='o', color='lightcoral', alpha=0.6, label='vehicle 38', s=50)  # 调整点的颜色、大小和透明度
plt.xlabel('X coordinates')
plt.ylabel('Y coordinates')
plt.grid(True)
plt.legend()
plt.tight_layout()  # 改进布局
plt.show()
