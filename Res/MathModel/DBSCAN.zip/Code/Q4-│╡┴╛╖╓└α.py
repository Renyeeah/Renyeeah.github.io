import pandas as pd
import matplotlib.pyplot as plt
from utils import *

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//4//D.csv')
car_ids = set(list(df['vehicle_id']))
car_ids = list(car_ids)

def inCross(x, y):
    if x*x + y*y <= 100**2:
        return True
    return False

car_ids_road = car_ids.copy()
i = 0
for id in car_ids:
    stop_x, stop_y = Q4getStopPoint(id, df)
    if inCross(stop_x, stop_y):
        car_ids_road.remove(id)


beginPoints = [(48.27, 496.27), (-496.22, 71.29), (-48.27, -496.27), (495.39, -21.7)]

X = []
Y = []
for id in car_ids:
    if Q4getBeginPoint(id, df)[0] == beginPoints[0][0]:
        X.append(Q4getStopPoint(id, df)[0])
        Y.append(Q4getStopPoint(id, df)[1])

X1 = df['x']
Y1 = df['y']
plt.figure(figsize=(6, 6), dpi=80)
plt.scatter(X1, Y1, marker='o', c='lightgray')
plt.scatter(X, Y, marker='o', c='purple')
plt.scatter(beginPoints[0][0], beginPoints[0][1], marker='o', c='red', s=[150])
plt.show()

# for id in car_ids_road:
#     if Q4getBeginPoint(id, df)[0] == beginPoints[3][0] and Q4getStopPoint(id, df)[1] > 200:
#         print(id)


