from utils import *

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//3//C6.csv')

X = df['x']
Y = df['y']

plt.figure(figsize=(5, 5))
plt.scatter(X, Y, marker='o', color='lightcoral', label='vehicle')
plt.ylabel('a')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()