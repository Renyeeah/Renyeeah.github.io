import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//4//D.csv')
car_ids = set(list(df['vehicle_id']))



X = []
Y = []
X1 = []
Y1 = []
for id in car_ids:
    df_filtered = df[df['vehicle_id'] == id]
    X.append(df_filtered.iloc[0]['x'])
    Y.append(df_filtered.iloc[0]['y'])
    X1.append(df_filtered.iloc[-1]['x'])
    Y1.append(df_filtered.iloc[-1]['y'])

X = df['x']
Y = df['y']
beginPoints = [(48.27, 496.27), (-496.22, 71.29), (-48.27, -496.27), (495.39, -21.7)]
bg0 = [x[0] for x in beginPoints]
bg1 = [x[1] for x in beginPoints]

plt.figure(figsize=(6, 6), dpi=80)
plt.scatter(X, Y, marker='o', c='lightblue')
plt.scatter(X1, Y1, marker='o', c='purple')
plt.scatter(bg0, bg1, marker='o', c='red')
plt.show()

