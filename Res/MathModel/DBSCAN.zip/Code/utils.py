import pandas as pd
import matplotlib.pyplot as plt
import math
from collections import Counter
import numpy as np
import random

# 清理数据
def clearData(df):
    cross = [
        (-11.44, -1.26),
        (-2.94, 12.02),
        (33.73, -3.77),
        (4.46, -11.54),
        (-11.51, 0.22),
    ]
    df_filtered = df[np.sqrt((df['x'] - cross[4][0])**2 + (df['y'] - cross[4][1])**2) <= 100]
    return df_filtered

def Q2_clearData(df, distance):
    cross = [
        (11.54, 4.46),
        (-2.94, 12.02),
        (33.73, -3.77),
        (4.46, -11.54),
        (-11.51, 0.22),
        (-12.02, -2.94),
        (18.94, 1.04),
    ]
    df_filtered = df[np.sqrt((df['x'] - cross[5][0])**2 + (df['y'] - cross[5][1])**2) <= distance]
    return df_filtered

def get_a(id, df):
    V = get_v(id, df)
    length = len(V)

    A = []
    for i in range(len(V)):
        if i == 0:
            continue

        a = V[i][1] - V[i-1][1]
        A.append((V[i][0], a))

    return A

def get_v(id, df):
    df_filtered = df[df['vehicle_id'] == id]
    t1 = list(df_filtered['time'])
    t = [int(x) for x in t1]
    x = list(df_filtered['x'])
    y = list(df_filtered['y'])
    length = len(x)

    V = []

    for i in range(length):
        if i == 0:
            continue

        v = math.sqrt((x[i] - x[i-1])**2 + (y[i] - y[i-1])**2)
        V.append((t[i], v))

    return V

def get_v(id, df):
    df_filtered = df[df['vehicle_id'] == id]
    t1 = list(df_filtered['time'])
    t = [int(x) for x in t1]
    x = list(df_filtered['x'])
    y = list(df_filtered['y'])
    length = len(x)

    V = []

    for i in range(length):
        if i == 0:
            continue

        v = math.sqrt((x[i] - x[i-1])**2 + (y[i] - y[i-1])**2)
        V.append((t[i], v))

    return V

def isStop(id, df):
    V = get_v(id, df)
    list = [i[1] for i in V]
    count = Counter(list)
    if count[0.0] < 5:
        return 1
    else:
        return 0

def getStopTime(id, df):
    A = get_a(id, df)
    if isStop(id, df) == 0:
        list = [i[1] for i in A]
        count = Counter(list)
        most_common_element, most_common_count = count.most_common(1)[0]
        return A[list.index(most_common_element)][0]

def normalization(data):
    data_array = np.array(data)

    # 分别获取 x 和 y 的值
    x_values = data_array[:, 0]
    y_values = data_array[:, 1]

    # 对 x 和 y 分别进行归一化
    x_min, x_max = x_values.min(), x_values.max()
    y_min, y_max = y_values.min(), y_values.max()

    x_normalized = (x_values - x_min) / (x_max - x_min)
    y_normalized = (y_values - y_min) / (y_max - y_min)

    # 将归一化后的 x 和 y 合并回去
    normalized_data = list(zip(x_normalized, y_normalized))
    return normalized_data

def dbscan(Data, Eps, MinPts):
    def dist(t1, t2):
        dis = math.sqrt((np.power((t1[0] - t2[0]), 2) + np.power((t1[1] - t2[1]), 2)))
        # print("两点之间的距离为："+str(dis))
        return dis

    num = len(Data)  # 点的个数
    # print("点的个数："+str(num))
    unvisited = [i for i in range(num)]  # 没有访问到的点的列表
    # print(unvisited)
    visited = []  # 已经访问的点的列表
    C = [-1 for i in range(num)]
    # C为输出结果，默认是一个长度为num的值全为-1的列表
    # 用k来标记不同的簇，k = -1表示噪声点
    k = -1
    # 如果还有没访问的点
    while len(unvisited) > 0:
        # 随机选择一个unvisited对象
        p = random.choice(unvisited)
        unvisited.remove(p)
        visited.append(p)
        # N为p的epsilon邻域中的对象的集合
        N = []
        for i in range(num):
            if (dist(Data[i], Data[p]) <= Eps):  # and (i!=p):
                N.append(i)
        # 如果p的epsilon邻域中的对象数大于指定阈值，说明p是一个核心对象
        if len(N) >= MinPts:
            k = k + 1
            # print(k)
            C[p] = k
            # 对于p的epsilon邻域中的每个对象pi
            for pi in N:
                if pi in unvisited:
                    unvisited.remove(pi)
                    visited.append(pi)
                    # 找到pi的邻域中的核心对象，将这些对象放入N中
                    # M是位于pi的邻域中的点的列表
                    M = []
                    for j in range(num):
                        if (dist(Data[j], Data[pi]) <= Eps):  # and (j!=pi):
                            M.append(j)
                    if len(M) >= MinPts:
                        for t in M:
                            if t not in N:
                                N.append(t)
                # 若pi不属于任何簇，C[pi] == -1说明C中第pi个值没有改动
                if C[pi] == -1:
                    C[pi] = k
        # 如果p的epsilon邻域中的对象数小于指定阈值，说明p是一个噪声点
        else:
            C[p] = -1

    return C

def Q4getBeginPoint(id, df):
    df_filtered = df[df['vehicle_id'] == id]
    return df_filtered.iloc[0]['x'], df_filtered.iloc[0]['y']

def Q4getStopPoint(id, df):
    df_filtered = df[df['vehicle_id'] == id]
    return df_filtered.iloc[-1]['x'], df_filtered.iloc[-1]['y']