import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from utils import *

df = pd.read_csv('C://Users//RenyeZhang//Desktop//math//fujian//1//A1.csv')

A = get_a(46, df)
X = [x[0] for x in A]
Y = [x[1] for x in A]
plt.figure(figsize=(8, 8))
plt.scatter(X, Y, marker='o', color='blue', label='vehicle')
plt.ylabel('a')
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()